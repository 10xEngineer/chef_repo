# GateOne @ 10xEngineer.me
 
Working in progress. Based current master.
 
For development install the GateOne using 'gateone' cookbook and use 
 
    setup.py install
 
in shared folder /gateone to install latest code.

## Lab Connector


