:mod:`remote_syslog.py` - A module to send syslog messaged directly over UDP
============================================================================

.. moduleauthor:: Christian Stigen Larsen

.. automodule:: remote_syslog
    :members:
    :private-members:
