The Help Plugin
===============
