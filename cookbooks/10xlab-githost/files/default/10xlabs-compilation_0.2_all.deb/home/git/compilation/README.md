# 10xLabs compilation service

## Hooks

Git `pre-receive` commit hooks to trigger compilation.
