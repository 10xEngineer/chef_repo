#!/bin/sh

gem install bundler --no-ri --no-rdoc
cd /home/git/compilation
bundle 