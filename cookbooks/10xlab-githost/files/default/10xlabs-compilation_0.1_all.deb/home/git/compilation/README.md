# 10xLabs compilation service


## Hooks

Git `pre-receive` commit hooks to trigger compilation.

**TODO** deployment model (need to maintain minimum dependencies)
**TODO** `10xlabs-compile.sh` configuration to ssh to the right compilation box