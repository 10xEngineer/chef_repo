#!/usr/bin/env ruby

$LOAD_PATH.unshift File.dirname(__FILE__)
$stdout.sync = true

require 'grit'
require 'yajl'
require 'tmpdir'
require 'fileutils'
require 'definition/metadata'
require 'definition/vm'
require '10xlabs/microcloud'

# read configuration
config_file = "/home/compile/.10xlabs-compile.json"
config = Yajl::Parser.parse(File.open(config_file))

# TODO pre-receive hook is not getting references when using clone from remote repository
# TODO consider cloning local repository (shared via some kind of networking system)
# https://trello.com/card/gitolite-pre-receive-hook/50067c2712a969ae032917f4/21
def prepare_repo(temp_dir, repo, rev = nil)
  repo = "ssh://#{repo}" unless repo.match /^ssh\:\/\//

  git = Grit::Git.new(".")

  options = {
    :quiet => false,
    :verbose => true,
    :progress => true,
    :branch => "master",
    :timeout => false
  }

  begin
    git.clone(options, repo, temp_dir)
  rescue => e
    puts "prepare_repo: git.clone failed"
    puts e.inspect
  end

  if rev
    repo = Grit::Repo.new(temp_dir)
    repo.git.run("", "checkout", "", {}, [rev])
  end

  temp_dir
end

Dir.mktmpdir do |repo_dir|
  # parse arguments
  repo = ARGV.shift
  lab_name = ARGV.shift
  lab_token = ARGV.shift
  repo_rev = ARGV.shift
  repo_ref = ARGV.shift

  # get repository
  prepare_repo(repo_dir, repo, repo_rev)
  puts "Compile environment ready."

  #repo_dir = "/Users/radim/tmp/labs/source"

  # verify pre-requisites
  metadata_rb = File.join(repo_dir, "metadata.rb")
  unless File.exists? metadata_rb
    puts "Invalid lab definition: no metadata.rb"

    # FIXME exit 1 aborts the push 
    # FIXME need to find more elegant solution
  else
    # read metadata
    m = Metadata.new(metadata_rb, repo_rev)
    begin 
      m.evaluate
    rescue Exception => e
      puts "Metadata evaluation failed: #{e.message}"

      exit 99
    end

    json_def = m.to_json
    puts "Temporary definition output:"

    puts json_def

    # push to microcloud
    # TODO handle return code
    # TODO security model
    @microcloud = TenxLabs::Microcloud.new(config["endpoint"])
    lab = @microcloud.post_ext("/labs/#{lab_name}/versions", m.to_obj)
  end
end

# push to microcloud
# FIXME how to lookup lab definition
# => git url is located within lab definition
# => implicit authentication


# FIXME ensure cleanup on failure too
# remove fragments
puts "Compilation fragments removed."

