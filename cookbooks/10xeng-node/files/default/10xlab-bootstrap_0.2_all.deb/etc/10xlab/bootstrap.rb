cookbook_path "/var/10xlab/cookbooks"
role_path "/var/10xlab/roles"
data_bag_path "/var/10xlab/data_bags"
file_cache_path "/var/10xlab"